/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Sahan Sankalpa
 */
public class AddRecord {
    Statement stmt;
    
     public void AddSociety(String Sname, String district, String sID,String sDate ){
        try {
            stmt = DbConnection.getStatementConnection();

            stmt.executeUpdate("INSERT INTO societydetails VALUES('"+Sname+"', '"+sID+"', '"+district+"','"+sDate+"')");
        }
       
       catch(Exception e){
           e.printStackTrace();
       }
    }
     
     public void AddPlayer(String name, String Id, String age, String society, String SId, String status, String batting,String order,String bowling,String action,String position) {
        try {
            stmt = DbConnection.getStatementConnection();
            stmt.executeUpdate("INSERT INTO playerdetails VALUES('"+name+"', '"+Id+"', '"+age+"','"+society+"','"+SId+"','"+status+"','"+batting+"','"+order+"','"+bowling+"','"+action+"','"+position+"')");
        }
       
        catch(Exception e){
           e.printStackTrace();
       }
    }

     public void CreatenewUser(String name, String Id, String pass) {
        try {
            stmt = DbConnection.getStatementConnection();
            stmt.executeUpdate("INSERT INTO userdetails VALUES('"+name+"', '"+Id+"', '"+pass+"')");
        }
       
        catch(SQLException e){
       }
    }
     
     
}
