/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Dhanushka
 */
public class UpdateRecord {
    
    Statement stmt;        
    
    public void UpdatePlayer(String ID, String Name,int Age,String Sname,String Status,String Batting,String Order,String Bowling,String Action,String Position){
        try {
            stmt = DbConnection.getStatementConnection();

            stmt.executeUpdate("UPDATE playerdetails SET Name='"+Name+"', Age='"+Age+"', SocietyName='"+Sname+"',PlayerStatus='"+Status+"', Batting='"+Sname+"', BattingOrder='"+Order+"', Bowling='"+Bowling+"', BowlingAction='"+Action+"', Position='"+Position+"' WHERE IDNumber='"+ID+"' ");
        }
       
       catch(Exception e){
           e.printStackTrace();
       }
    }
    
         
     public void Fpassword(String Id, String pass){
        try {
            stmt = DbConnection.getStatementConnection();

            stmt.executeUpdate("UPDATE userdetails SET Password = '"+pass+"' WHERE UserID = '"+Id+"'" ); // update password

        }
       
       catch(SQLException e){
       }
    }
    
}
