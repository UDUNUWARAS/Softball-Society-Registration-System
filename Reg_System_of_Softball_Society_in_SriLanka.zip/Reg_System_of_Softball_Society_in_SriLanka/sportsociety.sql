-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2023 at 05:36 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sportsociety`
--

-- --------------------------------------------------------

--
-- Table structure for table `playerdetails`
--

CREATE TABLE `playerdetails` (
  `Name` varchar(30) NOT NULL,
  `IDNumber` varchar(20) NOT NULL,
  `Age` int(20) NOT NULL,
  `SocietyName` varchar(20) NOT NULL,
  `SocietyID` varchar(20) NOT NULL,
  `PlayerStatus` varchar(20) NOT NULL,
  `Batting` varchar(20) NOT NULL,
  `BattingOrder` varchar(20) NOT NULL,
  `Bowling` varchar(20) NOT NULL,
  `BowlingAction` varchar(20) NOT NULL,
  `Position` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `playerdetails`
--

INSERT INTO `playerdetails` (`Name`, `IDNumber`, `Age`, `SocietyName`, `SocietyID`, `PlayerStatus`, `Batting`, `BattingOrder`, `Bowling`, `BowlingAction`, `Position`) VALUES
('Danu', '0069', 30, 'Birds', 'L1', 'Batsman', 'Birds', 'Middle order', 'Right arm', 'Medium fast', 'Player');

-- --------------------------------------------------------

--
-- Table structure for table `societydetails`
--

CREATE TABLE `societydetails` (
  `SocietyName` varchar(15) NOT NULL,
  `SocietyID` varchar(15) NOT NULL,
  `District` varchar(20) NOT NULL,
  `Date` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `societydetails`
--

INSERT INTO `societydetails` (`SocietyName`, `SocietyID`, `District`, `Date`) VALUES
('Lions', 'Kandy', 'L1', '2023/01.12');

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

CREATE TABLE `userdetails` (
  `UserName` varchar(15) NOT NULL,
  `UserID` varchar(15) NOT NULL,
  `Password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userdetails`
--

INSERT INTO `userdetails` (`UserName`, `UserID`, `Password`) VALUES
('123123', 'Yasitha', '321321'),
('Sahan', '4747', '4141'),
('sahan', '001', 'sahan123'),
('Upeka', 'upeka', '123'),
('sampath', '0010', '1234'),
('Dilan', 'D1', '12345'),
('Danushka', '0069', 'D12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `playerdetails`
--
ALTER TABLE `playerdetails`
  ADD PRIMARY KEY (`IDNumber`);

--
-- Indexes for table `societydetails`
--
ALTER TABLE `societydetails`
  ADD PRIMARY KEY (`SocietyID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
